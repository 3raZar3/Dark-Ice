<?php
// degree of two => hostname, vote link, image(optional), points
$tab_sites = array(
	1	=> array("bgtop100.com","http://bgtop100.com/","http://bgtop100.com/banners/bgtop100.gif",1),
	2	=> array("www.xtremetop100.com","http://www.xtremetop100.com/","http://www.xtremeTop100.com/votenew.jpg",1),
	4	=> array("wow.top100arena.com","http://wow.top100arena.com/","http://wow.top100arena.com/banner/WoW.jpg",1),
	8	=> array("www.gtop100.com","http://www.gtop100.com/","http://www.gtop100.com/images/votebutton.jpg",1),
	16	=> array("www.gamesites100.net","http://www.gamesites100.net/","http://www.gamesites100.net/images/nvotebutton.jpg",1),
	32	=> array("bgchart.net","http://bgchart.net/","http://bgchart.net/img/bgchart2.jpg",1),
	64	=> array("www.topfreegameservers.com","http://www.topfreegameservers.com/","http://www.topfreegameservers.com/images/vote.jpg",1),
);
?>